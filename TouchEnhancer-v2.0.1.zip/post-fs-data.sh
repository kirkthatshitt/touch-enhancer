#!/system/bin/sh
# Ensure service script is ready to run at boot
exit 0
