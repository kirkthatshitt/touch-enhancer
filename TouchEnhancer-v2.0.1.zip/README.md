# Touch Enhancer v2.0.1

**Improves touch responsiveness and reduces input latency.**  
Optimized for Any device and similar devices.  
This module automatically adjusts the touch sample rate based on your display’s refresh rate for smoother and more accurate touch response.

---

## ⚙️ Features
- Adaptive touch sample rate (180 / 240 / 300Hz)
- Boosts input responsiveness on boot
- Works automatically after device startup
- No performance penalty
- Magisk 23.0+ compatible (tested up to Magisk 30.4)

---

## 🧩 Installation
1. Flash the `.zip` file via Magisk Manager or custom recovery.  
2. Reboot your device.  
3. Enjoy smoother touch response instantly.

---

## 🆕 Changelog

### v2.0.1
- Removed license requirement (now free for all users)  
- Added proper update-ready structure for Magisk  
- Improved stability on boot  
- Polished installation script  

### v2.0.0
- Enhanced input boost control  
- Improved refresh rate detection logic  
- Added CPU input boost compatibility  

### v1.0.0
- Initial release  
- Basic touch sample rate boost  
- Improved overall responsiveness  

---

## 📱 Compatibility
- Android 10 to Android 15  
- Magisk 23.0+ (including 30.4)  
- Works with LineageOS, OneUI, and other custom ROMs  

---

## 💬 Developer
**Author:** kirkthatshitt  
**Version:** 2.0.1  
**GitHub:** [@kirkthatshitt](https://github.com/kirkthatshitt)  
**Telegram:** [@katari](https://t.me/katari)

---

## ❤️ Support Development
If you like this module, consider supporting future updates!

**Ko-fi:** [ko-fi.com/kirkthatshitt](https://ko-fi.com/kirkthatshitt)  
**PayPal:** [paypal.me/kirkthatshitt](https://paypal.me/kirkthatshitt)

---